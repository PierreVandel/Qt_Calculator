var classbak_calc_1_1_c_op_opos =
[
    [ "friendlyName", "classbak_calc_1_1_c_op_opos.html#a83147be0cccc0f6bfa5f7c61fb9eb712", null ],
    [ "toString", "classbak_calc_1_1_c_op_opos.html#ab6e28321ea84864a7d677dd35c59523a", null ],
    [ "getVal", "classbak_calc_1_1_c_op_opos.html#aea88b5cd1a693ff1631d9a12f1f369cd", null ]
];