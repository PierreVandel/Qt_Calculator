var searchData=
[
  ['optypeptr_76',['opTypePtr',['../classbak_calc_1_1_c_binary_operator.html#aa45d0f07d2070ecca43beba305047be9',1,'bakCalc::CBinaryOperator::opTypePtr()'],['../classbak_calc_1_1_c_unary_operator.html#aa45d0f07d2070ecca43beba305047be9',1,'bakCalc::CUnaryOperator::opTypePtr()']]]
];
