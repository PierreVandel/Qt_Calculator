var searchData=
[
  ['bakcalc_53',['bakCalc',['../namespacebak_calc.html',1,'']]]
];
