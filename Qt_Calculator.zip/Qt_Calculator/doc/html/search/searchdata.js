var indexSectionsWithContent =
{
  0: "abcefglmorst",
  1: "ce",
  2: "b",
  3: "acfglorst",
  4: "m",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type"
};

