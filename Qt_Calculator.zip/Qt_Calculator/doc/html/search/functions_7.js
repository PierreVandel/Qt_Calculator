var searchData=
[
  ['setleft_68',['setLeft',['../classbak_calc_1_1_c_binary_operator.html#a2e9d8ad6835390c822316b278ac09553',1,'bakCalc::CBinaryOperator']]],
  ['setoperand_69',['setOperand',['../classbak_calc_1_1_c_unary_operator.html#ac8fa65e48035f6bc487cb19978e4b00c',1,'bakCalc::CUnaryOperator']]],
  ['setright_70',['setRight',['../classbak_calc_1_1_c_binary_operator.html#a3597a77f0b0c52dc8b6a27841f3582af',1,'bakCalc::CBinaryOperator']]]
];
