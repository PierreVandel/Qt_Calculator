var classbak_calc_1_1_c_result =
[
    [ "friendlyName", "classbak_calc_1_1_c_result.html#a125801a8978d1d35da15552ea4011d0c", null ],
    [ "toString", "classbak_calc_1_1_c_result.html#a86412f21d82b99aa3444ad89a34e222d", null ],
    [ "getVal", "classbak_calc_1_1_c_result.html#abc0f2ac89f74121004af59e92a161e05", null ]
];