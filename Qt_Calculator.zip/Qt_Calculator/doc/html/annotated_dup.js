var annotated_dup =
[
    [ "bakCalc", "namespacebak_calc.html", [
      [ "CResult", "classbak_calc_1_1_c_result.html", "classbak_calc_1_1_c_result" ],
      [ "ExpressionConstructor", "classbak_calc_1_1_expression_constructor.html", "classbak_calc_1_1_expression_constructor" ],
      [ "ExpressionConstructorStd", "classbak_calc_1_1_expression_constructor_std.html", "classbak_calc_1_1_expression_constructor_std" ],
      [ "ExpressionConstructorSci", "classbak_calc_1_1_expression_constructor_sci.html", "classbak_calc_1_1_expression_constructor_sci" ],
      [ "CValue", "classbak_calc_1_1_c_value.html", "classbak_calc_1_1_c_value" ],
      [ "CBinaryOperator", "classbak_calc_1_1_c_binary_operator.html", "classbak_calc_1_1_c_binary_operator" ],
      [ "CUnaryOperator", "classbak_calc_1_1_c_unary_operator.html", "classbak_calc_1_1_c_unary_operator" ],
      [ "COpPlus", "classbak_calc_1_1_c_op_plus.html", "classbak_calc_1_1_c_op_plus" ],
      [ "COpMinus", "classbak_calc_1_1_c_op_minus.html", "classbak_calc_1_1_c_op_minus" ],
      [ "COpMult", "classbak_calc_1_1_c_op_mult.html", "classbak_calc_1_1_c_op_mult" ],
      [ "COpDiv", "classbak_calc_1_1_c_op_div.html", "classbak_calc_1_1_c_op_div" ],
      [ "COpSqrt", "classbak_calc_1_1_c_op_sqrt.html", "classbak_calc_1_1_c_op_sqrt" ],
      [ "COpInv", "classbak_calc_1_1_c_op_inv.html", "classbak_calc_1_1_c_op_inv" ],
      [ "COpOpos", "classbak_calc_1_1_c_op_opos.html", "classbak_calc_1_1_c_op_opos" ],
      [ "COpPow", "classbak_calc_1_1_c_op_pow.html", "classbak_calc_1_1_c_op_pow" ]
    ] ]
];