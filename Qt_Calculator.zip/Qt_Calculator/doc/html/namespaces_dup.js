var namespaces_dup =
[
    [ "bakCalc", "namespacebak_calc.html", "namespacebak_calc" ]
];