#include "qcalc.h"
#include <sstream>
#include <iomanip>
#include <limits>
#include <QMessageBox>

QCalc::QCalc(QWidget *parent)
    : QWidget(parent)
{
  ui.setupUi(this);
  m_pOpConstr = std::make_shared<bakCalc::ExpressionConstructorSci<valType>>();
}

/*!\param bScientific \c true when calculator switch to scientific mode, \c false otherwise.
*/
void QCalc::setScientificMode(bool bScientific)
{
  m_pResult = nullptr;
  ui.edtOperation->setText("");
  ui.edtResultat->setText("0");

  if (bScientific)
    m_pOpConstr = std::make_shared<bakCalc::ExpressionConstructorSci<valType>>();
  else
    m_pOpConstr = std::make_shared<bakCalc::ExpressionConstructorStd<valType>>();
}

/*!\param c The typed character. Can only be a digit or '.'.
*/
void QCalc::AppendChar(char c)
{
  bool bDotPresent = false;

  std::string str;
  if (m_bJustValidated && !m_pResult)
    str = "0";
  else
    str = ui.edtResultat->text().toStdString();
  m_bJustValidated = false;

  if (str.find_first_of(".,") != std::string::npos)
    bDotPresent = true;

  size_t nLimit = std::numeric_limits<long double>::digits10 + (bDotPresent?1:0);
  if (str.length() >= nLimit)
    return;
  
  if (str == "0" && c != '.')
    str.back() = c;
  else if (c != '.' || !bDotPresent)
    str.push_back(c);

  ui.edtResultat->setText(str.c_str());
}

/*!\param newop The operator to append. Can be a bakCalc::CBinaryOperator or a bakCalc::CUnaryOperator
*/
void QCalc::AppendOperator(std::shared_ptr<bakCalc::CResult<valType>> newop)
{
  valTypePtr newval = std::make_shared<bakCalc::CValue<valType>>(getValue());
  
  try{
    m_pResult = m_pOpConstr->AppendOperationElement(m_pResult, newval);
  }
  catch (const std::logic_error& e)
  {
    QMessageBox::critical(this, "Erreur", e.what());
    throw;
  }
  catch (const std::runtime_error& e)
  {
  }

  if (newop)
  {
    try{
      m_pResult = m_pOpConstr->AppendOperationElement(m_pResult, newop);
    }
    catch (const std::exception& e)
    {
      QMessageBox::critical(this, "Erreur", e.what());
      throw;
    }
  }

  ui.edtOperation->setText(m_pResult->toString().c_str());
  ui.edtResultat->setText("0");
}

QCalc::valType QCalc::getValue()
{
  std::string str{ ui.edtResultat->text().toStdString() };
  long double retval;
  try
  {
    retval = std::stold(str);
  }
  catch (const std::invalid_argument&)
  {
    retval = 0;
  }
  return retval;
}

void QCalc::btnDel()
{
  std::string str{ ui.edtResultat->text().toStdString() };
  str.pop_back();
  if (str.empty())
    str = "0";
  ui.edtResultat->setText(str.c_str());
}

void QCalc::btnPlus()
{
  AppendOperator(std::make_shared<bakCalc::COpPlus<valType>>());
}

void  QCalc::btnMinus()
{
  AppendOperator(std::make_shared<bakCalc::COpMinus<valType>>());
}

void  QCalc::btnMult()
{
  AppendOperator(std::make_shared<bakCalc::COpMult<valType>>());
}

void QCalc::btnDiv()
{
  AppendOperator(std::make_shared<bakCalc::COpDiv<valType>>());
}

void  QCalc::btnSqrt()
{
  AppendOperator(std::make_shared<bakCalc::COpSqrt<valType>>());
}

void  QCalc::btnInv()
{
  AppendOperator(std::make_shared<bakCalc::COpInv<valType>>());
}

void  QCalc::btnPow()
{
  AppendOperator(std::make_shared<bakCalc::COpPow<valType>>());
}

void  QCalc::btnOp()
{
  AppendOperator(std::make_shared<bakCalc::COpOpos<valType>>());
}

void  QCalc::btnValid()
{
  AppendOperator(nullptr);

  ui.edtOperation->setText((m_pResult->toString() + " =").c_str());
  std::stringstream stream;
  stream << std::setprecision(std::numeric_limits<long double>::digits10) << m_pResult->getVal();
  ui.edtResultat->setText(stream.str().c_str());

  emit eval(ui.edtOperation->text() + " " + ui.edtResultat->text());

  m_pResult = nullptr;
  m_bJustValidated = true;
}

