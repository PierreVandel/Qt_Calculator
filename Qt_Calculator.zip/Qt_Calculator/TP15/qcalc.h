#pragma once

#include <QtWidgets/QWidget>
#include "ui_qcalc.h"
#include "Operation.h"

/*!\brief Main class
 *
 * This class represent the main widget: the calculator
 */
class QCalc : public QWidget
{
    Q_OBJECT

public:
    //!\brief Constructor
    QCalc(QWidget *parent = 0);

private:
    Ui::QCalcClass ui; ///< GUI defined by Qt Designer
    using valType = long double;  ///< Type alias of long double to get best precision
    using opTypePtr = std::shared_ptr<bakCalc::CResult<valType>>; ///< Type alias of a pointer to a bakCalc::CResult
    using valTypePtr = std::shared_ptr<bakCalc::CValue<valType>>; ///< Type alias of a pointer to a bakCalc::CValue
    opTypePtr m_pResult;  ///< Root object of mathematical expression
    bool m_bJustValidated = false; ///< Is true just after clicking on '=' button

    std::shared_ptr<bakCalc::ExpressionConstructor<valType>> m_pOpConstr; ///< A pointer to the object used to construct mathematical expression

    //!\brief Append one character to the current number
    void AppendChar(char c);
    //!\brief Append an operator to the current mathematical expression.
    void AppendOperator(std::shared_ptr<bakCalc::CResult<valType>> newop);
    //!\brief Return the numeric evaluation of the current expression
    valType getValue();

public slots:
    void btn0() { AppendChar('0'); }  ///< Called on '0' button press
    void btn1() { AppendChar('1'); }  ///< Called on '1' button press
    void btn2() { AppendChar('2'); }  ///< Called on '2' button press
    void btn3() { AppendChar('3'); }  ///< Called on '3' button press
    void btn4() { AppendChar('4'); }  ///< Called on '4' button press
    void btn5() { AppendChar('5'); }  ///< Called on '5' button press
    void btn6() { AppendChar('6'); }  ///< Called on '6' button press
    void btn7() { AppendChar('7'); }  ///< Called on '7' button press
    void btn8() { AppendChar('8'); }  ///< Called on '8' button press
    void btn9() { AppendChar('9'); }  ///< Called on '9' button press
    void btnDot() { AppendChar('.'); }  ///< Called on '.' button press

    void btnDel();   ///< Called on backspace button press
    void btnPlus();  ///< Called on '+' button press
    void btnMinus(); ///< Called on '-' button press
    void btnMult();  ///< Called on '*' button press
    void btnDiv();   ///< Called on '/' button press
    void btnSqrt();  ///< Called on 'sqrt' button press
    void btnInv();   ///< Called on '1/x' button press
    void btnPow();   ///< Called on '^' button press
    void btnOp();    ///< Called on '+/-' button press
    void btnValid(); ///< Called on '=' button press

    //!\brief Triggered when switching from one mode to the other
    void setScientificMode(bool bScientific);

signals:
    /*!\brief Emitted whenever an evaluation is done.
    * \param strExpr contains the representation of "expression = value"
    */
    void eval(const QString& strExpr);
};
