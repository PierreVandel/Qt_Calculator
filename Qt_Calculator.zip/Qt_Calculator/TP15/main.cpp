#include "qmainwnd.h"
#include <QtWidgets/QApplication>
#include <QtCore/QDebug>
#include "Operation.h"
#include <complex>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QMainWnd w;
    w.show();

    return a.exec();
}
