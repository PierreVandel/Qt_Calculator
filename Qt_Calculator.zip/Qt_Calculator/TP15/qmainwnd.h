#ifndef QMAINWND_H
#define QMAINWND_H

#include <QWidget>
#include "ui_qmainwnd.h"

class QMainWnd : public QWidget
{
    Q_OBJECT

public:
    QMainWnd(QWidget *parent = 0);
    ~QMainWnd();

private:
    Ui::QMainWnd ui;

public slots:
    //!\brief Append a string to the history
    void AppendToHist(const QString& strExpr);
};

#endif // QMAINWND_H
