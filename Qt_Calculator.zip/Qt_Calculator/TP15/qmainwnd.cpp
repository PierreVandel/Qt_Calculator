#include "qmainwnd.h"

QMainWnd::QMainWnd(QWidget *parent)
    : QWidget(parent)
{
  ui.setupUi(this);
  ui.btnShow->setVisible(false);

  QObject::connect(ui.calc, &QCalc::eval, this, &QMainWnd::AppendToHist);
}

QMainWnd::~QMainWnd()
{

}

//!\param strExpr The string to append
void QMainWnd::AppendToHist(const QString& strExpr)
{
  ui.lstHisto->addItem(strExpr);
}