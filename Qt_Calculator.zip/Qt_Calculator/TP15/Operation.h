/*!\brief Template declaration of Calculator classes
 * \author Benjamin ALBOUY-KISSI
 * \date 21/04/2016
 */
#pragma once
#include <memory>
#include <string>
#include <stdexcept>
#include <sstream>
#include <cmath>

#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)

/*!\brief This is the namespace of all Calculator stuff
 *
 * \note Each template is parametered by a \c valType typename which is the numeric type of calculation. This type can be every intrinsic type (\c double, \c float, \c int, etc...) 
 * and also \c std::complex<...>.
 */
namespace bakCalc {
  template<typename valType> class CResult;

  /*!\brief Base class for all mathematical expression construction classes
   *
   * A mathematical expression is a tree of CResult objects. The tree follows the composite design pattern where leaves are CValue objects and nodes can be either
   * CUnaryOperator (one child) or CBinaryOperator (two children) objects.
   *
   * ExpressionConstructor derived classes must override ExpressionConstructor::AppendOperationElement function to construct the tree. By this way, they construct the tree by their own algorithm.
   * bakCalc implementation offers two algorithms through ExpressionConstructorSci and ExpressionConstructorStd classes which respectively implement a scientific and a 
   * standard calculator.
   *
   * ExpressionConstructor derived classes are supposed to be "naturally" used. This is to say that you append expression elements one by one, from left to right. 
   * For exemple, to construct the expression \f$1+2*3^4\f$, you should use the following code, supposing that \c ctr is an ExpressionConstructor object :
   * \code{.cpp}
std::shared_ptr<CResult<double>> expr;
expr = ctr.AppendOperationElement(expr, std::make_shared<CValue<double>>(1));
expr = ctr.AppendOperationElement(expr, std::make_shared<COpPlus<double>>());
expr = ctr.AppendOperationElement(expr, std::make_shared<CValue<double>>(2));
expr = ctr.AppendOperationElement(expr, std::make_shared<COpMult<double>>());
expr = ctr.AppendOperationElement(expr, std::make_shared<CValue<double>>(3));
expr = ctr.AppendOperationElement(expr, std::make_shared<COpPow<double>>());
expr = ctr.AppendOperationElement(expr, std::make_shared<CValue<double>>(4));

//If you want to get a std::string representation of the expression just use CResult::toString. If you want a numeric evaluation of the expression, use CResult::getVal :
std::cout << expr.toString() << " = " << expr.getVal() << std::endl;
\endcode
   * The way to understand the expression is determined by the underlying algorithm of the ExpressionConstructor derived class of \c ctr object. If \c ctr is one
   * of ExpressionConstructorSci, then \c expr is computed as \f$(1+(2*(3^4)))\f$ according to usual operator precedences. If \c ctr is one of ExpressionConstructorStd, then
   * \c expr is computed as \f$((1+2)*3)^4\f$.
   *
   * \see https://en.wikipedia.org/wiki/Composite_pattern | ExpressionConstructorSci | ExpressionConstructorStd
   */
  template<typename valType>
  class ExpressionConstructor
  {
  public:
    /*!\brief Append an element to a tree representing an expression
     * 
     * \param [in] expression the current tree to which to add an element
     * \param [in] element the mathematical element to add to the tree
     * \return The new root of the tree
     *
     * \note The tree root is susceptible to change. Developpers must use the returned value as the new root.
     *
     * This pure virtual function is a placeholder for derived classes.
     *
     */
    virtual std::shared_ptr<CResult<valType>> AppendOperationElement(const std::shared_ptr<CResult<valType>>& expression, const std::shared_ptr<CResult<valType>>& element) const = 0;
  };


  /*!\brief Operation construction following a standard calculator rules
   *
   * With this class, expression \f$\sqrt{2}+2*3^4\f$ is constructed as the following graph :
   * \dot
   digraph expressionStd {
     sqrt -> sqrt2;
     plus -> sqrt;
     plus -> two;
     mult -> plus;
     mult ->three;
     pow -> mult;
     pow -> four;
     plus [label="+"];
     mult [label="*"];
     pow [label="^"];
     sqrt [label="sqrt"];
     sqrt2 [label="2"];
     two [label="2"];
     three [label="3"];
     four [label="4"];
   }   \enddot
   * \see ExpressionConstructor
   */
  template<typename valType>
  class ExpressionConstructorStd : public ExpressionConstructor<valType>
  {
  public:
    /*!\brief Append an element to a tree representing an expression
     * 
     * The implemented algorithm just adds the \p toAppend object to the right of the mathematical expression. Some verifications are done on \p expression and \p toAppend to avoid loss of information.
     * So the function is suceptible to throw some \c std::runtime_error exceptions. If such exception is thrown, follow indications of \c std::runtime_error::what to understand the problem.
     *
     * \note By the way, this function has not been efficiently tested. Some bugs are eventually there and can raise some \c std::logic_error exceptions.
     *
     * \see ExpressionConstructor::AppendOperationElement
     */
    std::shared_ptr<CResult<valType>> AppendOperationElement(const std::shared_ptr<CResult<valType>>& expression, const std::shared_ptr<CResult<valType>>& toAppend) const override;
  };

  /*!\brief Operation construction following a scientific calculator rules
   *
   * With this class, expression \f$\sqrt{2}+2*3^4\f$ is constructed as the following tree :
   * \dot
   digraph expressionSci {
     plus -> sqrt;
     plus -> mult;
     sqrt -> sqrt2;
     mult -> two;
     mult -> pow;
     pow -> three;
     pow -> four;
     plus [label="+"];
     mult [label="*"];
     pow [label="^"];
     sqrt [label="sqrt"];
     sqrt2 [label="2"];
     two [label="2"];
     three [label="3"];
     four [label="4"];
   }
   \enddot
   *
   * \see ExpressionConstructor
   */
  template<typename valType>
  class ExpressionConstructorSci : public ExpressionConstructor<valType>
  {
  public:
    /*!\brief Append an element to a tree representing an expression
     * 
     * The implemented algorithm adds the \p toAppend object to the right of the mathematical expression <b>by respecting operator precedences</b>. Some verifications are done
     * on \p expression and \p toAppend to avoid loss of information.
     * So the function is suceptible to throw some \c std::runtime_error exceptions. If such exception is thrown, follow indications of \c std::runtime_error::what to
     * understand the problem.
     *
     * \note By the way, this function has not been efficiently tested. Some bugs are eventually there and can raise some \c std::logic_error exceptions.
     *
     * \see ExpressionConstructor::AppendOperationElement
     */
    std::shared_ptr<CResult<valType>> AppendOperationElement(const std::shared_ptr<CResult<valType>>& expression, const std::shared_ptr<CResult<valType>>& toAppend) const override;
  };

  /*!\brief Base class for mathematical expression
   *
   * A mathematical expression is a tree of CResult objects. The tree follows the composite design pattern where leaves are CValue objects and nodes can be either
   * CUnaryOperator (one child) or CBinaryOperator (two children) objects.
   * \dot
   digraph composite {
     graph [splines=ortho, rankdir=BT, ranksep=1, nodesep=1]
     node [shape=record, width=1.5]
     edge [arrowhead=onormal, weight=10]
     CResult [height=1]
     CValue -> CResult
     CUnaryOperator -> CResult
     CBinaryOperator -> CResult
     edge [dir=both, arrowhead=normal, arrowtail=odiamond, weight=0]
     CBinaryOperator -> CResult [headlabel="left"]
     CBinaryOperator -> CResult [headlabel="right"]
     CUnaryOperator -> CResult [taillabel="operand", arrowhead=odiamond, arrowtail=normal, labeldistance=2]
   }   
   \enddot
   *
   * The mathematical expression can be constructed by your own using CBinaryOperator::setLeft, CBinaryOperator::setRight and 
   * CUnaryOperator::setOperand on a root object of your choice. Alternatively, you can use one of ExpressionConstructor derived classes.
   * 
   * If you want to get a \c std::string representation of the expression just use CResult::toString. If you want a numeric evaluation of the expression, use CResult::getVal.
   *
   * \see https://en.wikipedia.org/wiki/Composite_pattern | CValue | CBinaryOperator | CUnaryOperator
   */
  template<typename valType>
  class CResult
  {
  protected:
    /*!\brief Returns a human readable name for this expression element type.
     *
     * This value is used when error occurs to build an understandable string for exceptions.
     */
    virtual std::string friendlyName() const = 0;
  public:
    //!\brief Returns a std::string representation of the expression from this node.
    virtual std::string toString() const = 0;
    //!\brief Returns a \c valType numeric evaluation of the expression from this node.
    virtual valType getVal() const = 0;
  };

  /*!\brief This class is a numeric value in a mathematical expression
   */
  template<typename valType>
  class CValue : public CResult<valType>
  {
    //!\brief The numeric value
    valType m_value;
  protected:
    /*!\brief returns "value"
     * \see CResult::friendlyName
     */
    virtual std::string friendlyName() const override { return "value"; }
  public:
    //!\brief Construct a value
    //!\param val The numeric value to encapsulate
    CValue(const valType& val) : m_value{ val }{}
    //!\brief Construct a value set to 0
    CValue() : m_value(0){}
    std::string toString() const  override;
    //!\brief Returns the numeric value.
    virtual valType getVal() const  override { return m_value; }
  };

  //!\brief Returns a std::string representation of this number.
  template<typename valType> 
  std::string CValue<valType>::toString() const
  {
    std::stringstream res;
    res << m_value;
    return res.str();
  }

  /*!\brief Base class for all binary operators
   *
   * This kind of tree node has two children: left and right operands:
   * \dot
   digraph CBinaryOperator {
     operator -> "left:CResult";
     operator -> "right:CResult";
     operator [color=yellow, style=filled, label="operator:CBinaryOperator"];
   }
   \enddot
   * Each operator has its own precedence represented by an \c unsigned \c int returned by CBinaryOperator::getPrecedence. 
   * The precedence is the inverse of the priority. The lower the precedence is, the higher the priority is.
   */
  template<typename valType>
  class CBinaryOperator : public CResult<valType>
  {
    //!\brief Type alias of pointer to CResult
    using opTypePtr = std::shared_ptr<CResult<valType>>;
    opTypePtr m_left;  ///<left operand
    opTypePtr m_right; ///<right operand

  protected:
    //!\brief If left operand is present, returns its std::string representation. Else it returns an empty string.
    std::string leftToString() const { if (m_left) return m_left->toString(); else return std::string{}; }
    //!\brief If right operand is present, returns its std::string representation. Else it returns an empty string.
    std::string rightToString() const { if (m_right) return m_right->toString(); else return std::string{}; }
    //!\brief If left operand is present, returns its numeric evaluation. Else it throws a std::runtime_error exception.
    valType leftVal() const { if (m_left) return m_left->getVal(); else throw std::runtime_error("Operator " + this->friendlyName() + " needs a left operand"); }
    //!\brief If right operand is present, returns its numeric evaluation. Else it throws a std::runtime_error exception.
    valType rightVal() const { if (m_right) return m_right->getVal(); else throw std::runtime_error("Operator " + this->friendlyName() + " needs a right operand"); }
  public:
    /*!\brief Set the left operand.
     * \param left A pointer to the operand
     */
    virtual void setLeft(opTypePtr left) { m_left = left; }
    /*!\brief Set the right operand.
    * \param right A pointer to the operand
    */
    virtual void setRight(opTypePtr right) { m_right = right; }
    //!\brief Returns a pointer to the left operand
    opTypePtr getLeft() { return m_left; }
    //!\brief Returns a pointer to the right operand
    opTypePtr getRight(){ return m_right; }
    //!\brief Returns the precedence of the operator.
    virtual unsigned int getPrecedence() = 0;
  };

  /*!\brief Base class for all unary operators
  *
  * This kind of tree node has one child: the operand:
  * \dot
  digraph CUnaryOperator {
  operator -> "operand:CResult";
  operator [color=yellow, style=filled, label="operator:CUnnaryOperator"];
  }
  \enddot
  */
  template<typename valType>
  class CUnaryOperator : public CResult<valType>
  {
    //!\brief Type alias of pointer to CResult
    using opTypePtr = std::shared_ptr<CResult<valType>>;
    opTypePtr m_operand; ///<The operand

  protected:
    //!\brief If operand is present, returns its std::string representation. Else it returns an empty string.
    std::string operandToString() const { if (m_operand) return m_operand->toString(); else return std::string{}; }
    //!\brief If operand is present, returns its numeric evaluation. Else it throws a std::runtime_error exception.
    valType operandVal() const { if (m_operand) return m_operand->getVal(); else throw std::runtime_error("Operator " + this->friendlyName() + " needs an operand"); }
  public:
    /*!\brief Set the operand.
    * \param operand A pointer to the operand
    */
    virtual void setOperand(opTypePtr operand) { m_operand = operand; }
    //!\brief Returns a pointer to the operand
    opTypePtr getOperand() { return m_operand; }
  };

  //!\brief Operator +
  template<typename valType>
  class COpPlus : public CBinaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "+"; }
  public:
    std::string toString() const override { return this->leftToString() + std::string{ " + " } + this->rightToString(); }
    valType getVal() const override { return this->leftVal() + this->rightVal(); }
    virtual unsigned int getPrecedence() { return 6; }
  };

  //!\brief Operator -
  template<typename valType>
  class COpMinus : public CBinaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "-"; }
  public:
    std::string toString() const override { return this->leftToString() + std::string{ " - " } + this->rightToString(); }
    valType getVal() const override { return this->leftVal() - this->rightVal(); }
    virtual unsigned int getPrecedence() { return 6; }
  };

  //!\brief Operator *
  template<typename valType>
  class COpMult : public CBinaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "*"; }
  public:
    std::string toString() const override { return this->leftToString() + std::string{ " * " } + this->rightToString(); }
    valType getVal() const override { return this->leftVal() * this->rightVal(); }
    virtual unsigned int getPrecedence() { return 5; }
  };

  //!\brief Operator /
  template<typename valType>
  class COpDiv : public CBinaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "/"; }
  public:
    std::string toString() const override { return this->leftToString() + std::string{ " / " } + this->rightToString(); }
    valType getVal() const override { return this->leftVal() / this->rightVal(); }
    virtual unsigned int getPrecedence() { return 5; }
  };

  //!\brief Operator square root
  template<typename valType>
  class COpSqrt : public CUnaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "sqrt"; }
  public:
    std::string toString() const override { return std::string{ " sqrt(" } + this->operandToString() + std::string{ ")" }; }
    valType getVal() const override { return sqrt(this->operandVal()); }
  };

  //!\brief Operator 1/x
  template<typename valType>
  class COpInv : public CUnaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "1 / (.)"; }
  public:
    std::string toString() const override { return std::string{ " 1 / (" } + this->operandToString() + std::string{ ")" }; }
    valType getVal() const override { return 1.0 / this->operandVal(); }
  };

  //!\brief Operator -(x)
  template<typename valType>
  class COpOpos : public CUnaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "- (.)"; }
  public:
    std::string toString() const override { return std::string{ " - (" } + this->operandToString() + std::string{ ")" }; }
    valType getVal() const override { return -this->operandVal(); }
  };

  //!\brief Operator ^
  template<typename valType>
  class COpPow : public CBinaryOperator<valType>
  {
  protected:
    std::string friendlyName() const override { return "^"; }
  public:
    std::string toString() const override { return this->leftToString() + std::string{ " ^ " } + this->rightToString(); }
    valType getVal() const override { return pow(this->leftVal(), this->rightVal()); }
    virtual unsigned int getPrecedence() { return 4; }
  };

  template<typename valType>
  std::shared_ptr<CResult<valType>> ExpressionConstructorStd<valType>::AppendOperationElement(const std::shared_ptr<CResult<valType>>& expression, const std::shared_ptr<CResult<valType>>& toAppend) const
  {
    //Trivial case : expression is nullptr
    if (!expression)
      return toAppend;

    auto ptrUnaryOpToAppend = std::dynamic_pointer_cast<CUnaryOperator<valType>>(toAppend);
    auto ptrBinaryOpToAppend = std::dynamic_pointer_cast<CBinaryOperator<valType>>(toAppend);
    auto ptrValueToAppend = std::dynamic_pointer_cast<CValue<valType>>(toAppend);

    auto ptrUnaryOpOperation = std::dynamic_pointer_cast<CUnaryOperator<valType>>(expression);
    auto ptrBinaryOpOperation = std::dynamic_pointer_cast<CBinaryOperator<valType>>(expression);
    auto ptrValueOperation = std::dynamic_pointer_cast<CValue<valType>>(expression);

    //if toAppend is an unary operator, verify that it has not already an operand
    if (ptrUnaryOpToAppend)
      if (ptrUnaryOpToAppend->getOperand())
        throw std::runtime_error("Operation construction failed because you tried to append an unary operator which has already an operand");

    //if toAppend is a binary operator, verify that it has not already a left operand
    if (ptrBinaryOpToAppend)
      if (ptrBinaryOpToAppend->getLeft())
        throw std::runtime_error("Operation construction failed because you tried to append a binary operator which has already a left operand");

    //if toAppend is a value, we can only append it to a binary operator
    if (ptrValueToAppend)
      if (ptrValueOperation || ptrUnaryOpOperation)
        throw std::runtime_error("Operation construction failed because you tried to append a value to a value or unary operator");

    //if expression is a value or unary operator, we can only append an unary or binary operator
    if (ptrValueOperation || ptrUnaryOpOperation)
    {
      if (ptrBinaryOpToAppend)
      {
        ptrBinaryOpToAppend->setLeft(expression);
        return ptrBinaryOpToAppend;
      }
      if (ptrUnaryOpToAppend)
      {
        ptrUnaryOpToAppend->setOperand(expression);
        return ptrUnaryOpToAppend;
      }
      throw std::logic_error("Unexpected behavior in function " + std::string(__FUNCTION__) + " in source file " __FILE__"(" TOSTRING(__LINE__) "). \n"
                             "Parameter expression was of type " + typeid(*(expression.get())).name() + " : " + expression->toString() + "\n"
                             "Parameter toAppend was of type " + typeid(*(toAppend.get())).name() + " : " + toAppend->toString());
    }

    //if expression is a binary operator, we can append everything
    if (ptrBinaryOpOperation)
    {
      if (ptrValueToAppend)
      {
        if (ptrBinaryOpOperation->getRight())
          throw std::runtime_error("Operation construction failed because you tried to append a value to a binary operator which has already a right operand");
        ptrBinaryOpOperation->setRight(ptrValueToAppend);
        return ptrBinaryOpOperation;
      }
      if (ptrUnaryOpToAppend && ptrBinaryOpOperation->getLeft() && ptrBinaryOpOperation->getRight())
      {
        ptrUnaryOpToAppend->setOperand(ptrBinaryOpOperation->getRight());
        ptrBinaryOpOperation->setRight(ptrUnaryOpToAppend);
        return ptrBinaryOpOperation;
      }
      if (ptrBinaryOpToAppend)
      {
        ptrBinaryOpToAppend->setLeft(expression);
        return ptrBinaryOpToAppend;
      }
      throw std::logic_error("Unexpected behavior in function " + std::string(__FUNCTION__) + " in source file " __FILE__"(" TOSTRING(__LINE__) "). \n"
                             "Parameter expression was of type " + typeid(*(expression.get())).name() + " : " + expression->toString() + "\n"
                             "Parameter toAppend was of type " + typeid(*(toAppend.get())).name() + " : " + toAppend->toString());
    }

    throw std::logic_error("Unexpected behavior in function " + std::string(__FUNCTION__) + " in source file " __FILE__"(" TOSTRING(__LINE__) "). \n"
                           "Parameter expression was of type " + typeid(*(expression.get())).name() + " : " + expression->toString() + "\n"
                           "Parameter toAppend was of type " + typeid(*(toAppend.get())).name() + " : " + toAppend->toString());
  }

  template<typename valType>
  std::shared_ptr<CResult<valType>> ExpressionConstructorSci<valType>::AppendOperationElement(const std::shared_ptr<CResult<valType>>& expression, const std::shared_ptr<CResult<valType>>& toAppend) const
  {
    //Trivial case : expression is nullptr
    if (!expression)
      return toAppend;

    auto ptrUnaryOpToAppend = std::dynamic_pointer_cast<CUnaryOperator<valType>>(toAppend);
    auto ptrBinaryOpToAppend = std::dynamic_pointer_cast<CBinaryOperator<valType>>(toAppend);
    auto ptrValueToAppend = std::dynamic_pointer_cast<CValue<valType>>(toAppend);

    auto ptrUnaryOpOperation = std::dynamic_pointer_cast<CUnaryOperator<valType>>(expression);
    auto ptrBinaryOpOperation = std::dynamic_pointer_cast<CBinaryOperator<valType>>(expression);
    auto ptrValueOperation = std::dynamic_pointer_cast<CValue<valType>>(expression);

    //if toAppend is an unary operator, verify that it has not already an operand
    if (ptrUnaryOpToAppend)
      if (ptrUnaryOpToAppend->getOperand())
        throw std::runtime_error("Operation construction failed because you tried to append an unary operator which has already an operand");

    //if toAppend is a binary operator, verify that it has not already a left operand
    if (ptrBinaryOpToAppend)
      if (ptrBinaryOpToAppend->getLeft())
        throw std::runtime_error("Operation construction failed because you tried to append a binary operator which has already a left operand");

    //if toAppend is a value, we can only append it to a binary operator
    if (ptrValueToAppend)
      if (ptrValueOperation || ptrUnaryOpOperation)
        throw std::runtime_error("Operation construction failed because you tried to append a value to a value or unary operator");

    //if expression is a value or unary operator, we can only append an unary or binary operator
    if (ptrValueOperation || ptrUnaryOpOperation)
    {
      if (ptrBinaryOpToAppend)
      {
        ptrBinaryOpToAppend->setLeft(expression);
        return ptrBinaryOpToAppend;
      }
      if (ptrUnaryOpToAppend)
      {
        ptrUnaryOpToAppend->setOperand(expression);
        return ptrUnaryOpToAppend;
      }
      throw std::logic_error("Unexpected behavior in function " + std::string(__FUNCTION__) + " in source file " __FILE__"(" TOSTRING(__LINE__) "). \n"
        "Parameter expression was of type " + typeid(*(expression.get())).name() + " : " + expression->toString() + "\n"
        "Parameter toAppend was of type " + typeid(*(toAppend.get())).name() + " : " + toAppend->toString());
    }

    //if expression is a binary operator, we can append everything
    if (ptrBinaryOpOperation)
    {
      if (ptrValueToAppend)
      {
        //browse binary operator tree to find a place to the right
        while (ptrBinaryOpOperation->getRight())
        {
          ptrBinaryOpOperation = std::dynamic_pointer_cast<CBinaryOperator<valType>>(ptrBinaryOpOperation->getRight());
          if (!ptrBinaryOpOperation)
            throw std::runtime_error("Operation construction failed because you tried to append a value to a binary operator tree which is complete");
        }
        ptrBinaryOpOperation->setRight(ptrValueToAppend);
        return expression;
      }
      if (ptrUnaryOpToAppend)
      {
        //browse binary operator tree to find the leaf the most to the right
        while (std::dynamic_pointer_cast<CBinaryOperator<valType>>(ptrBinaryOpOperation->getRight()))
        {
          ptrBinaryOpOperation = std::dynamic_pointer_cast<CBinaryOperator<valType>>(ptrBinaryOpOperation->getRight());
        }
        if (!ptrBinaryOpOperation->getRight())
          throw std::runtime_error("Operation construction failed because you tried to append an unary operator to a binary operator tree which is not complete");
        
        ptrUnaryOpToAppend->setOperand(ptrBinaryOpOperation->getRight());
        ptrBinaryOpOperation->setRight(ptrUnaryOpToAppend);
        return expression;
      }
      if (ptrBinaryOpToAppend)
      {
        //if the precedence of the operator to append is greater or equal to the precedence of the main operator, then the operator to append becomes the main operator
        if (ptrBinaryOpOperation->getPrecedence() <= ptrBinaryOpToAppend->getPrecedence())
        {
          ptrBinaryOpToAppend->setLeft(ptrBinaryOpOperation);
          return ptrBinaryOpToAppend;
        }
        //browse binary operator tree to find the place where the precedence is lesser or equal to the operator-to-append's precedence 
        while (ptrBinaryOpOperation->getPrecedence() > ptrBinaryOpToAppend->getPrecedence())
        {
          if (!std::dynamic_pointer_cast<CBinaryOperator<valType>>(ptrBinaryOpOperation->getRight()))
          {
            ptrBinaryOpToAppend->setLeft(ptrBinaryOpOperation->getRight());
            ptrBinaryOpOperation->setRight(ptrBinaryOpToAppend);
            return expression;
          }
          ptrBinaryOpOperation = std::dynamic_pointer_cast<CBinaryOperator<valType>>(ptrBinaryOpOperation->getRight());
        }
        ptrBinaryOpToAppend->setLeft(ptrBinaryOpOperation->getRight());
        ptrBinaryOpOperation->setRight(ptrBinaryOpToAppend);
        return expression;
      }
      throw std::logic_error("Unexpected behavior in function " + std::string(__FUNCTION__) + " in source file " __FILE__"(" TOSTRING(__LINE__) "). \n"
        "Parameter expression was of type " + typeid(*(expression.get())).name() + " : " + expression->toString() + "\n"
        "Parameter toAppend was of type " + typeid(*(toAppend.get())).name() + " : " + toAppend->toString());
    }

    throw std::logic_error("Unexpected behavior in function " + std::string(__FUNCTION__) + " in source file " __FILE__"(" TOSTRING(__LINE__) "). \n"
      "Parameter expression was of type " + typeid(*(expression.get())).name() + " : " + expression->toString() + "\n"
      "Parameter toAppend was of type " + typeid(*(toAppend.get())).name() + " : " + toAppend->toString());
  }
}

#undef TOSTRING
