/****************************************************************************
** Meta object code from reading C++ file 'qcalc.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.1.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../qcalc.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qcalc.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.1.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QCalc_t {
    const uint offsetsAndSize[54];
    char stringdata0[183];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_QCalc_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_QCalc_t qt_meta_stringdata_QCalc = {
    {
QT_MOC_LITERAL(0, 5), // "QCalc"
QT_MOC_LITERAL(6, 4), // "eval"
QT_MOC_LITERAL(11, 0), // ""
QT_MOC_LITERAL(12, 7), // "strExpr"
QT_MOC_LITERAL(20, 4), // "btn0"
QT_MOC_LITERAL(25, 4), // "btn1"
QT_MOC_LITERAL(30, 4), // "btn2"
QT_MOC_LITERAL(35, 4), // "btn3"
QT_MOC_LITERAL(40, 4), // "btn4"
QT_MOC_LITERAL(45, 4), // "btn5"
QT_MOC_LITERAL(50, 4), // "btn6"
QT_MOC_LITERAL(55, 4), // "btn7"
QT_MOC_LITERAL(60, 4), // "btn8"
QT_MOC_LITERAL(65, 4), // "btn9"
QT_MOC_LITERAL(70, 6), // "btnDot"
QT_MOC_LITERAL(77, 6), // "btnDel"
QT_MOC_LITERAL(84, 7), // "btnPlus"
QT_MOC_LITERAL(92, 8), // "btnMinus"
QT_MOC_LITERAL(101, 7), // "btnMult"
QT_MOC_LITERAL(109, 6), // "btnDiv"
QT_MOC_LITERAL(116, 7), // "btnSqrt"
QT_MOC_LITERAL(124, 6), // "btnInv"
QT_MOC_LITERAL(131, 6), // "btnPow"
QT_MOC_LITERAL(138, 5), // "btnOp"
QT_MOC_LITERAL(144, 8), // "btnValid"
QT_MOC_LITERAL(153, 17), // "setScientificMode"
QT_MOC_LITERAL(171, 11) // "bScientific"

    },
    "QCalc\0eval\0\0strExpr\0btn0\0btn1\0btn2\0"
    "btn3\0btn4\0btn5\0btn6\0btn7\0btn8\0btn9\0"
    "btnDot\0btnDel\0btnPlus\0btnMinus\0btnMult\0"
    "btnDiv\0btnSqrt\0btnInv\0btnPow\0btnOp\0"
    "btnValid\0setScientificMode\0bScientific"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCalc[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  152,    2, 0x06,    0 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,  155,    2, 0x0a,    2 /* Public */,
       5,    0,  156,    2, 0x0a,    3 /* Public */,
       6,    0,  157,    2, 0x0a,    4 /* Public */,
       7,    0,  158,    2, 0x0a,    5 /* Public */,
       8,    0,  159,    2, 0x0a,    6 /* Public */,
       9,    0,  160,    2, 0x0a,    7 /* Public */,
      10,    0,  161,    2, 0x0a,    8 /* Public */,
      11,    0,  162,    2, 0x0a,    9 /* Public */,
      12,    0,  163,    2, 0x0a,   10 /* Public */,
      13,    0,  164,    2, 0x0a,   11 /* Public */,
      14,    0,  165,    2, 0x0a,   12 /* Public */,
      15,    0,  166,    2, 0x0a,   13 /* Public */,
      16,    0,  167,    2, 0x0a,   14 /* Public */,
      17,    0,  168,    2, 0x0a,   15 /* Public */,
      18,    0,  169,    2, 0x0a,   16 /* Public */,
      19,    0,  170,    2, 0x0a,   17 /* Public */,
      20,    0,  171,    2, 0x0a,   18 /* Public */,
      21,    0,  172,    2, 0x0a,   19 /* Public */,
      22,    0,  173,    2, 0x0a,   20 /* Public */,
      23,    0,  174,    2, 0x0a,   21 /* Public */,
      24,    0,  175,    2, 0x0a,   22 /* Public */,
      25,    1,  176,    2, 0x0a,   23 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   26,

       0        // eod
};

void QCalc::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QCalc *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->eval((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->btn0(); break;
        case 2: _t->btn1(); break;
        case 3: _t->btn2(); break;
        case 4: _t->btn3(); break;
        case 5: _t->btn4(); break;
        case 6: _t->btn5(); break;
        case 7: _t->btn6(); break;
        case 8: _t->btn7(); break;
        case 9: _t->btn8(); break;
        case 10: _t->btn9(); break;
        case 11: _t->btnDot(); break;
        case 12: _t->btnDel(); break;
        case 13: _t->btnPlus(); break;
        case 14: _t->btnMinus(); break;
        case 15: _t->btnMult(); break;
        case 16: _t->btnDiv(); break;
        case 17: _t->btnSqrt(); break;
        case 18: _t->btnInv(); break;
        case 19: _t->btnPow(); break;
        case 20: _t->btnOp(); break;
        case 21: _t->btnValid(); break;
        case 22: _t->setScientificMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QCalc::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QCalc::eval)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject QCalc::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_QCalc.offsetsAndSize,
    qt_meta_data_QCalc,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_QCalc_t
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>


>,
    nullptr
} };


const QMetaObject *QCalc::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCalc::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QCalc.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int QCalc::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void QCalc::eval(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
