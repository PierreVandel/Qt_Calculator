/********************************************************************************
** Form generated from reading UI file 'qmainwnd.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QMAINWND_H
#define UI_QMAINWND_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcalc.h"

QT_BEGIN_NAMESPACE

class Ui_QMainWnd
{
public:
    QHBoxLayout *horizontalLayout;
    QCalc *calc;
    QVBoxLayout *verticalLayout_2;
    QPushButton *btnShow;
    QPushButton *btnHide;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListWidget *lstHisto;

    void setupUi(QWidget *QMainWnd)
    {
        if (QMainWnd->objectName().isEmpty())
            QMainWnd->setObjectName(QString::fromUtf8("QMainWnd"));
        QMainWnd->setEnabled(true);
        QMainWnd->resize(530, 300);
        QMainWnd->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background:#202D4B;\n"
"	font-family: \"Segoe UI\";\n"
"	font-size:9pt;\n"
"	color:rgb(255, 255, 255);\n"
"	selection-background-color:rgb(85, 170, 255);\n"
"	selection-color:rgb(255, 255, 255);\n"
"}\n"
"\n"
"QWidget:disabled {\n"
"	color:rgba(255, 255, 255, 76);\n"
"}\n"
"\n"
"/* QLabel */\n"
"QLabel {\n"
"	background:transparent;\n"
"}\n"
"\n"
"QLineEdit:focus, QDialog QPushButton:focus{\n"
"	border:1px solid #4775a2;\n"
"	outline:none;\n"
"}\n"
"\n"
"/* QLineEdit */\n"
"QLineEdit{\n"
"	border:0px;\n"
"	height:1.25em;\n"
"	padding:5px 10px 5px 10px;\n"
"}\n"
"QLineEdit:disabled{\n"
"	background:lightgray;\n"
"	color:gray;\n"
"}\n"
"\n"
"/* QPushButton */\n"
"QPushButton{\n"
"	border:0px;\n"
"	height:1.25em;\n"
"	padding:5px 10px 5px 10px;\n"
"	color:white;\n"
"}\n"
"QPushButton:pressed, QPushButton:checked {\n"
"    background-color: #2c4966;\n"
"}\n"
"QPushButton:hover:!pressed:!checked{\n"
"   background-color: #2c4966; /*should or may be different*/\n"
"}\n"
"QPushButton:disabled{\n"
"   ba"
                        "ckground-color: #9d9d9d;\n"
"}\n"
"\n"
"/* QListView */\n"
"QListView{\n"
"	border:0px;\n"
"	padding:0.3em 0.6em 0.3em 0.6em;\n"
"}\n"
"QListView::item{\n"
"	height:1.85em;\n"
"}\n"
"\n"
"/* QScrollBar */\n"
"QScrollBar:vertical {\n"
"    width: 1.75em;\n"
"    padding: 2em 0em 2em 0em;\n"
"}\n"
"QScrollBar::handle:vertical {\n"
"    background: #2c4966;\n"
"    min-height: 2em;\n"
"}\n"
"\n"
"QScrollBar::add-line:vertical,\n"
"QScrollBar::sub-line:vertical {\n"
"    background: #2c4966;\n"
"    height: 2em;\n"
"    subcontrol-origin: padding;\n"
"}\n"
"QScrollBar::add-line:vertical {\n"
"    subcontrol-position: bottom;\n"
"}\n"
"QScrollBar::sub-line:vertical {\n"
"    subcontrol-position: top;\n"
"}\n"
"\n"
"QScrollBar::up-arrow:vertical,\n"
"QScrollBar::down-arrow:vertical {\n"
"	background-repeat:no-repeat;\n"
"	background-position:center;\n"
"}\n"
"QScrollBar::up-arrow:vertical {\n"
"	background-image:url(:/icons/arrowU);\n"
"}\n"
"QScrollBar::down-arrow:vertical {\n"
"	background-image:url(:/icons/arrowD"
                        ");\n"
"}\n"
"\n"
"QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"    background: none;\n"
"}\n"
"\n"
"/* QSlider */\n"
"QSlider {\n"
"	background:transparent;\n"
"	height:1.25em;\n"
"}\n"
"QSlider::groove:horizontal {\n"
"	background:#2c4966;\n"
"	height:0.4em;\n"
"	margin:0.5em 0;\n"
"}\n"
"QSlider::handle:horizontal {\n"
"    background: #4775a2; \n"
"	margin:-0.75em 0;\n"
"	width:1em;\n"
"}\n"
"QSlider::handle:hover{\n"
"	background:rgb(85, 170, 255);\n"
"}\n"
"QSlider::groove:horizontal:disabled {\n"
"	background:rgba(44, 73, 102, 76);\n"
"}\n"
"QSlider::handle:horizontal:disabled {\n"
"    background: rgba(71, 117, 162, 76); \n"
"}\n"
""));
        horizontalLayout = new QHBoxLayout(QMainWnd);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        calc = new QCalc(QMainWnd);
        calc->setObjectName(QString::fromUtf8("calc"));

        horizontalLayout->addWidget(calc);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(-1, -1, 0, -1);
        btnShow = new QPushButton(QMainWnd);
        btnShow->setObjectName(QString::fromUtf8("btnShow"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btnShow->sizePolicy().hasHeightForWidth());
        btnShow->setSizePolicy(sizePolicy);
        btnShow->setStyleSheet(QString::fromUtf8("padding:3px;"));

        verticalLayout_2->addWidget(btnShow);

        btnHide = new QPushButton(QMainWnd);
        btnHide->setObjectName(QString::fromUtf8("btnHide"));
        sizePolicy.setHeightForWidth(btnHide->sizePolicy().hasHeightForWidth());
        btnHide->setSizePolicy(sizePolicy);
        btnHide->setStyleSheet(QString::fromUtf8("padding:3px;"));

        verticalLayout_2->addWidget(btnHide);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(QMainWnd);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));

        verticalLayout->addWidget(label);

        lstHisto = new QListWidget(QMainWnd);
        lstHisto->setObjectName(QString::fromUtf8("lstHisto"));
        lstHisto->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lstHisto->setFrameShape(QFrame::NoFrame);
        lstHisto->setEditTriggers(QAbstractItemView::NoEditTriggers);
        lstHisto->setProperty("showDropIndicator", QVariant(false));
        lstHisto->setSelectionMode(QAbstractItemView::NoSelection);

        verticalLayout->addWidget(lstHisto);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(QMainWnd);
        QObject::connect(btnShow, &QPushButton::clicked, lstHisto, qOverload<>(&QListWidget::show));
        QObject::connect(btnShow, &QPushButton::clicked, label, qOverload<>(&QLabel::show));
        QObject::connect(btnShow, &QPushButton::clicked, btnHide, qOverload<>(&QPushButton::show));
        QObject::connect(btnShow, &QPushButton::clicked, btnShow, qOverload<>(&QPushButton::hide));
        QObject::connect(btnHide, &QPushButton::clicked, lstHisto, qOverload<>(&QListWidget::hide));
        QObject::connect(btnHide, &QPushButton::clicked, label, qOverload<>(&QLabel::hide));
        QObject::connect(btnHide, &QPushButton::clicked, btnShow, qOverload<>(&QPushButton::show));
        QObject::connect(btnHide, &QPushButton::clicked, btnHide, qOverload<>(&QPushButton::hide));

        QMetaObject::connectSlotsByName(QMainWnd);
    } // setupUi

    void retranslateUi(QWidget *QMainWnd)
    {
        QMainWnd->setWindowTitle(QCoreApplication::translate("QMainWnd", "QMainWnd", nullptr));
        btnShow->setText(QCoreApplication::translate("QMainWnd", ">>", nullptr));
        btnHide->setText(QCoreApplication::translate("QMainWnd", "<<", nullptr));
        label->setText(QCoreApplication::translate("QMainWnd", "Historique", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QMainWnd: public Ui_QMainWnd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QMAINWND_H
