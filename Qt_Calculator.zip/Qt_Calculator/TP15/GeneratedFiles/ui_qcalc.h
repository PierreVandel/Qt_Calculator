/********************************************************************************
** Form generated from reading UI file 'qcalc.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QCALC_H
#define UI_QCALC_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QCalcClass
{
public:
    QVBoxLayout *verticalLayout;
    QLineEdit *edtOperation;
    QLineEdit *edtResultat;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *btnFnAv;
    QPushButton *pushButton;
    QGridLayout *gridLayout;
    QPushButton *btnOp;
    QPushButton *btn8;
    QPushButton *btnDot;
    QPushButton *btn2;
    QPushButton *btn7;
    QPushButton *btn3;
    QPushButton *btn9;
    QPushButton *btn0;
    QPushButton *btn1;
    QPushButton *btnDel;
    QPushButton *btnDiv;
    QPushButton *btnMult;
    QPushButton *btnValid;
    QPushButton *btnMinus;
    QPushButton *btn5;
    QPushButton *btn4;
    QPushButton *btnPlus;
    QPushButton *btn6;
    QPushButton *btnSqrt;
    QPushButton *btnInv;
    QPushButton *btnPow;

    void setupUi(QWidget *QCalcClass)
    {
        if (QCalcClass->objectName().isEmpty())
            QCalcClass->setObjectName(QString::fromUtf8("QCalcClass"));
        QCalcClass->resize(302, 285);
        QCalcClass->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	font: 8pt \"Segoe UI\";\n"
"}\n"
"#edtOperation{\n"
"	color:rgb(127, 127, 127);\n"
"}\n"
"#edtResultat{\n"
"	font: 75 18pt;\n"
"}\n"
"QPushButton{\n"
"	font-size : 14pt;\n"
"}\n"
"QLineEdit{\n"
"	border: none;\n"
"}"));
        verticalLayout = new QVBoxLayout(QCalcClass);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        edtOperation = new QLineEdit(QCalcClass);
        edtOperation->setObjectName(QString::fromUtf8("edtOperation"));
        edtOperation->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        edtOperation->setReadOnly(true);

        verticalLayout->addWidget(edtOperation);

        edtResultat = new QLineEdit(QCalcClass);
        edtResultat->setObjectName(QString::fromUtf8("edtResultat"));
        edtResultat->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        edtResultat->setReadOnly(true);

        verticalLayout->addWidget(edtResultat);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        btnFnAv = new QPushButton(QCalcClass);
        btnFnAv->setObjectName(QString::fromUtf8("btnFnAv"));
        btnFnAv->setCheckable(true);
        btnFnAv->setChecked(true);
        btnFnAv->setAutoExclusive(true);

        horizontalLayout_2->addWidget(btnFnAv);

        pushButton = new QPushButton(QCalcClass);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setCheckable(true);
        pushButton->setAutoExclusive(true);

        horizontalLayout_2->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout_2);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        btnOp = new QPushButton(QCalcClass);
        btnOp->setObjectName(QString::fromUtf8("btnOp"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btnOp->sizePolicy().hasHeightForWidth());
        btnOp->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnOp, 9, 0, 1, 1);

        btn8 = new QPushButton(QCalcClass);
        btn8->setObjectName(QString::fromUtf8("btn8"));
        sizePolicy.setHeightForWidth(btn8->sizePolicy().hasHeightForWidth());
        btn8->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn8, 5, 1, 1, 1);

        btnDot = new QPushButton(QCalcClass);
        btnDot->setObjectName(QString::fromUtf8("btnDot"));
        sizePolicy.setHeightForWidth(btnDot->sizePolicy().hasHeightForWidth());
        btnDot->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnDot, 9, 2, 1, 1);

        btn2 = new QPushButton(QCalcClass);
        btn2->setObjectName(QString::fromUtf8("btn2"));
        sizePolicy.setHeightForWidth(btn2->sizePolicy().hasHeightForWidth());
        btn2->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn2, 8, 1, 1, 1);

        btn7 = new QPushButton(QCalcClass);
        btn7->setObjectName(QString::fromUtf8("btn7"));
        sizePolicy.setHeightForWidth(btn7->sizePolicy().hasHeightForWidth());
        btn7->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn7, 5, 0, 1, 1);

        btn3 = new QPushButton(QCalcClass);
        btn3->setObjectName(QString::fromUtf8("btn3"));
        sizePolicy.setHeightForWidth(btn3->sizePolicy().hasHeightForWidth());
        btn3->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn3, 8, 2, 1, 1);

        btn9 = new QPushButton(QCalcClass);
        btn9->setObjectName(QString::fromUtf8("btn9"));
        sizePolicy.setHeightForWidth(btn9->sizePolicy().hasHeightForWidth());
        btn9->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn9, 5, 2, 1, 1);

        btn0 = new QPushButton(QCalcClass);
        btn0->setObjectName(QString::fromUtf8("btn0"));
        sizePolicy.setHeightForWidth(btn0->sizePolicy().hasHeightForWidth());
        btn0->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn0, 9, 1, 1, 1);

        btn1 = new QPushButton(QCalcClass);
        btn1->setObjectName(QString::fromUtf8("btn1"));
        sizePolicy.setHeightForWidth(btn1->sizePolicy().hasHeightForWidth());
        btn1->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn1, 8, 0, 1, 1);

        btnDel = new QPushButton(QCalcClass);
        btnDel->setObjectName(QString::fromUtf8("btnDel"));
        sizePolicy.setHeightForWidth(btnDel->sizePolicy().hasHeightForWidth());
        btnDel->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnDel, 3, 0, 1, 1);

        btnDiv = new QPushButton(QCalcClass);
        btnDiv->setObjectName(QString::fromUtf8("btnDiv"));
        sizePolicy.setHeightForWidth(btnDiv->sizePolicy().hasHeightForWidth());
        btnDiv->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnDiv, 3, 1, 1, 1);

        btnMult = new QPushButton(QCalcClass);
        btnMult->setObjectName(QString::fromUtf8("btnMult"));
        sizePolicy.setHeightForWidth(btnMult->sizePolicy().hasHeightForWidth());
        btnMult->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnMult, 3, 2, 1, 1);

        btnValid = new QPushButton(QCalcClass);
        btnValid->setObjectName(QString::fromUtf8("btnValid"));
        sizePolicy.setHeightForWidth(btnValid->sizePolicy().hasHeightForWidth());
        btnValid->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnValid, 8, 3, 2, 1);

        btnMinus = new QPushButton(QCalcClass);
        btnMinus->setObjectName(QString::fromUtf8("btnMinus"));
        sizePolicy.setHeightForWidth(btnMinus->sizePolicy().hasHeightForWidth());
        btnMinus->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnMinus, 3, 3, 1, 1);

        btn5 = new QPushButton(QCalcClass);
        btn5->setObjectName(QString::fromUtf8("btn5"));
        sizePolicy.setHeightForWidth(btn5->sizePolicy().hasHeightForWidth());
        btn5->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn5, 6, 1, 1, 1);

        btn4 = new QPushButton(QCalcClass);
        btn4->setObjectName(QString::fromUtf8("btn4"));
        sizePolicy.setHeightForWidth(btn4->sizePolicy().hasHeightForWidth());
        btn4->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn4, 6, 0, 1, 1);

        btnPlus = new QPushButton(QCalcClass);
        btnPlus->setObjectName(QString::fromUtf8("btnPlus"));
        sizePolicy.setHeightForWidth(btnPlus->sizePolicy().hasHeightForWidth());
        btnPlus->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnPlus, 5, 3, 2, 1);

        btn6 = new QPushButton(QCalcClass);
        btn6->setObjectName(QString::fromUtf8("btn6"));
        sizePolicy.setHeightForWidth(btn6->sizePolicy().hasHeightForWidth());
        btn6->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btn6, 6, 2, 1, 1);

        btnSqrt = new QPushButton(QCalcClass);
        btnSqrt->setObjectName(QString::fromUtf8("btnSqrt"));
        sizePolicy.setHeightForWidth(btnSqrt->sizePolicy().hasHeightForWidth());
        btnSqrt->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnSqrt, 0, 0, 1, 1);

        btnInv = new QPushButton(QCalcClass);
        btnInv->setObjectName(QString::fromUtf8("btnInv"));
        sizePolicy.setHeightForWidth(btnInv->sizePolicy().hasHeightForWidth());
        btnInv->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnInv, 0, 1, 1, 1);

        btnPow = new QPushButton(QCalcClass);
        btnPow->setObjectName(QString::fromUtf8("btnPow"));
        sizePolicy.setHeightForWidth(btnPow->sizePolicy().hasHeightForWidth());
        btnPow->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnPow, 0, 2, 1, 1);


        verticalLayout->addLayout(gridLayout);

        QWidget::setTabOrder(btn0, btn1);
        QWidget::setTabOrder(btn1, btn2);
        QWidget::setTabOrder(btn2, btn3);
        QWidget::setTabOrder(btn3, btn4);
        QWidget::setTabOrder(btn4, btn5);
        QWidget::setTabOrder(btn5, btn6);
        QWidget::setTabOrder(btn6, btn7);
        QWidget::setTabOrder(btn7, btn8);
        QWidget::setTabOrder(btn8, btn9);
        QWidget::setTabOrder(btn9, btnPlus);
        QWidget::setTabOrder(btnPlus, btnMinus);
        QWidget::setTabOrder(btnMinus, btnMult);
        QWidget::setTabOrder(btnMult, btnDiv);
        QWidget::setTabOrder(btnDiv, btnDel);
        QWidget::setTabOrder(btnDel, btnDot);
        QWidget::setTabOrder(btnDot, btnValid);
        QWidget::setTabOrder(btnValid, btnOp);
        QWidget::setTabOrder(btnOp, pushButton);
        QWidget::setTabOrder(pushButton, btnFnAv);
        QWidget::setTabOrder(btnFnAv, edtResultat);
        QWidget::setTabOrder(edtResultat, edtOperation);

        retranslateUi(QCalcClass);
        QObject::connect(btnFnAv, &QPushButton::toggled, btnPow, &QPushButton::setVisible);
        QObject::connect(btnFnAv, &QPushButton::toggled, btnInv, &QPushButton::setVisible);
        QObject::connect(btnFnAv, &QPushButton::toggled, btnSqrt, &QPushButton::setVisible);
        QObject::connect(btn7, SIGNAL(clicked()), QCalcClass, SLOT(btn7()));
        QObject::connect(btn8, SIGNAL(clicked()), QCalcClass, SLOT(btn8()));
        QObject::connect(btn9, SIGNAL(clicked()), QCalcClass, SLOT(btn9()));
        QObject::connect(btnDiv, SIGNAL(clicked()), QCalcClass, SLOT(btnDiv()));
        QObject::connect(btn4, SIGNAL(clicked()), QCalcClass, SLOT(btn4()));
        QObject::connect(btn5, SIGNAL(clicked()), QCalcClass, SLOT(btn5()));
        QObject::connect(btn6, SIGNAL(clicked()), QCalcClass, SLOT(btn6()));
        QObject::connect(btnMult, SIGNAL(clicked()), QCalcClass, SLOT(btnMult()));
        QObject::connect(btn1, SIGNAL(clicked()), QCalcClass, SLOT(btn1()));
        QObject::connect(btn2, SIGNAL(clicked()), QCalcClass, SLOT(btn2()));
        QObject::connect(btn3, SIGNAL(clicked()), QCalcClass, SLOT(btn3()));
        QObject::connect(btnMinus, SIGNAL(clicked()), QCalcClass, SLOT(btnMinus()));
        QObject::connect(btnOp, SIGNAL(clicked()), QCalcClass, SLOT(btnOp()));
        QObject::connect(btn0, SIGNAL(clicked()), QCalcClass, SLOT(btn0()));
        QObject::connect(btnDot, SIGNAL(clicked()), QCalcClass, SLOT(btnDot()));
        QObject::connect(btnPlus, SIGNAL(clicked()), QCalcClass, SLOT(btnPlus()));
        QObject::connect(btnValid, SIGNAL(clicked()), QCalcClass, SLOT(btnValid()));
        QObject::connect(btnDel, SIGNAL(clicked()), QCalcClass, SLOT(btnDel()));
        QObject::connect(btnSqrt, SIGNAL(clicked()), QCalcClass, SLOT(btnSqrt()));
        QObject::connect(btnInv, SIGNAL(clicked()), QCalcClass, SLOT(btnInv()));
        QObject::connect(btnPow, SIGNAL(clicked()), QCalcClass, SLOT(btnPow()));
        QObject::connect(btnFnAv, SIGNAL(toggled(bool)), QCalcClass, SLOT(setScientificMode(bool)));

        QMetaObject::connectSlotsByName(QCalcClass);
    } // setupUi

    void retranslateUi(QWidget *QCalcClass)
    {
        QCalcClass->setWindowTitle(QCoreApplication::translate("QCalcClass", "QCalc", nullptr));
        edtResultat->setText(QCoreApplication::translate("QCalcClass", "0", nullptr));
        btnFnAv->setText(QCoreApplication::translate("QCalcClass", "Scientifique", nullptr));
        pushButton->setText(QCoreApplication::translate("QCalcClass", "Normale", nullptr));
        btnOp->setText(QCoreApplication::translate("QCalcClass", "+/-", nullptr));
        btn8->setText(QCoreApplication::translate("QCalcClass", "8", nullptr));
#if QT_CONFIG(shortcut)
        btn8->setShortcut(QCoreApplication::translate("QCalcClass", "8", nullptr));
#endif // QT_CONFIG(shortcut)
        btnDot->setText(QCoreApplication::translate("QCalcClass", ",", nullptr));
#if QT_CONFIG(shortcut)
        btnDot->setShortcut(QCoreApplication::translate("QCalcClass", ".", nullptr));
#endif // QT_CONFIG(shortcut)
        btn2->setText(QCoreApplication::translate("QCalcClass", "2", nullptr));
#if QT_CONFIG(shortcut)
        btn2->setShortcut(QCoreApplication::translate("QCalcClass", "2", nullptr));
#endif // QT_CONFIG(shortcut)
        btn7->setText(QCoreApplication::translate("QCalcClass", "7", nullptr));
#if QT_CONFIG(shortcut)
        btn7->setShortcut(QCoreApplication::translate("QCalcClass", "7", nullptr));
#endif // QT_CONFIG(shortcut)
        btn3->setText(QCoreApplication::translate("QCalcClass", "3", nullptr));
#if QT_CONFIG(shortcut)
        btn3->setShortcut(QCoreApplication::translate("QCalcClass", "3", nullptr));
#endif // QT_CONFIG(shortcut)
        btn9->setText(QCoreApplication::translate("QCalcClass", "9", nullptr));
#if QT_CONFIG(shortcut)
        btn9->setShortcut(QCoreApplication::translate("QCalcClass", "9", nullptr));
#endif // QT_CONFIG(shortcut)
        btn0->setText(QCoreApplication::translate("QCalcClass", "0", nullptr));
#if QT_CONFIG(shortcut)
        btn0->setShortcut(QCoreApplication::translate("QCalcClass", "0", nullptr));
#endif // QT_CONFIG(shortcut)
        btn1->setText(QCoreApplication::translate("QCalcClass", "1", nullptr));
#if QT_CONFIG(shortcut)
        btn1->setShortcut(QCoreApplication::translate("QCalcClass", "1", nullptr));
#endif // QT_CONFIG(shortcut)
        btnDel->setText(QCoreApplication::translate("QCalcClass", "\342\206\220", nullptr));
#if QT_CONFIG(shortcut)
        btnDel->setShortcut(QCoreApplication::translate("QCalcClass", "Backspace", nullptr));
#endif // QT_CONFIG(shortcut)
        btnDiv->setText(QCoreApplication::translate("QCalcClass", "/", nullptr));
#if QT_CONFIG(shortcut)
        btnDiv->setShortcut(QCoreApplication::translate("QCalcClass", "/", nullptr));
#endif // QT_CONFIG(shortcut)
        btnMult->setText(QCoreApplication::translate("QCalcClass", "*", nullptr));
#if QT_CONFIG(shortcut)
        btnMult->setShortcut(QCoreApplication::translate("QCalcClass", "*", nullptr));
#endif // QT_CONFIG(shortcut)
        btnValid->setText(QCoreApplication::translate("QCalcClass", "=", nullptr));
#if QT_CONFIG(shortcut)
        btnValid->setShortcut(QCoreApplication::translate("QCalcClass", "Enter", nullptr));
#endif // QT_CONFIG(shortcut)
        btnMinus->setText(QCoreApplication::translate("QCalcClass", "-", nullptr));
#if QT_CONFIG(shortcut)
        btnMinus->setShortcut(QCoreApplication::translate("QCalcClass", "-", nullptr));
#endif // QT_CONFIG(shortcut)
        btn5->setText(QCoreApplication::translate("QCalcClass", "5", nullptr));
#if QT_CONFIG(shortcut)
        btn5->setShortcut(QCoreApplication::translate("QCalcClass", "5", nullptr));
#endif // QT_CONFIG(shortcut)
        btn4->setText(QCoreApplication::translate("QCalcClass", "4", nullptr));
#if QT_CONFIG(shortcut)
        btn4->setShortcut(QCoreApplication::translate("QCalcClass", "4", nullptr));
#endif // QT_CONFIG(shortcut)
        btnPlus->setText(QCoreApplication::translate("QCalcClass", "+", nullptr));
#if QT_CONFIG(shortcut)
        btnPlus->setShortcut(QCoreApplication::translate("QCalcClass", "+", nullptr));
#endif // QT_CONFIG(shortcut)
        btn6->setText(QCoreApplication::translate("QCalcClass", "6", nullptr));
#if QT_CONFIG(shortcut)
        btn6->setShortcut(QCoreApplication::translate("QCalcClass", "6", nullptr));
#endif // QT_CONFIG(shortcut)
        btnSqrt->setText(QCoreApplication::translate("QCalcClass", "\342\210\232x", nullptr));
        btnInv->setText(QCoreApplication::translate("QCalcClass", "1/x", nullptr));
        btnPow->setText(QCoreApplication::translate("QCalcClass", "x^y", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QCalcClass: public Ui_QCalcClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QCALC_H
